import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const root = path.resolve(process.argv[2] ?? '.');
const require = createRequire(path.join(root, 'package.json'));
const ts = require('typescript');
const file = path.join(root, 'apps/runtime-web/src/main.ts');
const source = fs.readFileSync(file, 'utf8');
const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true);
const names = [
  'activeMediaObjectForSurface', 'activeMediaObjectIdForSurface',
  'activeScreenShareObjectForSurface', 'activeWhiteboardObjectForSurface',
  'activeMarkdownBoardObjectForSurface', 'activeRemoteBrowserObjectForSurface',
  'activePdfPresentationObjectForSurface', 'activeImageViewerObjectForSurface',
  'activeVideoPlayerObjectForSurface', 'findActiveObjectByType',
  'findActiveScreenShareObject', 'findLocalActiveScreenShareObject',
  'findActiveWhiteboardObject', 'findActiveMarkdownBoardObject',
  'findActiveRemoteBrowserObject', 'findActivePdfPresentationObject',
  'findActiveImageViewerObject', 'findActiveVideoPlayerObject',
  'findRemoteBrowserObjectNeedingLiveKitRoom',
  'currentWhiteboardObject', 'currentMarkdownBoardObject', 'currentRemoteBrowserObject',
  'currentPdfPresentationObject', 'currentImageViewerObject', 'currentVideoPlayerObject',
  'activeWhiteboardObjects', 'activeMarkdownBoardObjects', 'activeRemoteBrowserObjects',
  'activePdfPresentationObjects'
];
const publicNames = names.filter(n => n !== 'findActiveObjectByType');
const functions = names.map(name => {
  const matches = ast.statements.filter(n => ts.isFunctionDeclaration(n) && n.name?.text === name);
  if (matches.length !== 1) throw new Error(`Expected one function: ${name}`);
  return matches[0];
});
const bodies = functions.map(n => source.slice(n.getStart(ast), n.end));
const selectorImport = ast.statements.find(n => ts.isImportDeclaration(n) && n.moduleSpecifier.text === './media/media-object-state.js');
if (!selectorImport) throw new Error('Missing source selector import');
const movedSelectors = selectorImport.importClause.namedBindings.elements.filter(n => !['physicalRemoteBrowserObjectForMediaTrack','physicalScreenShareObjectForMediaTrack'].includes(n.name.text));
const moduleImports = `import {\n  SCREEN_SHARE_OBJECT_TYPE, WHITEBOARD_OBJECT_TYPE, MARKDOWN_BOARD_OBJECT_TYPE,\n  REMOTE_BROWSER_OBJECT_TYPE, PDF_PRESENTATION_OBJECT_TYPE, IMAGE_VIEWER_OBJECT_TYPE, VIDEO_PLAYER_OBJECT_TYPE,\n  type MediaObjectInstance, type RoomMediaObjectsState, type ScreenShareObjectState,\n  type WhiteboardState, type MarkdownBoardState, type RemoteBrowserObjectState,\n  type PdfPresentationState, type ImageViewerState, type VideoPlayerState\n} from "@vrata/shared-types";\nimport {\n${movedSelectors.map(n => `  ${n.getText(ast)}`).join(',\n')}\n} from "./media-object-state.js";\n`;
const interfaceText = `\nexport interface MediaObjectQueriesContext {\n  // The room snapshot and selection can be replaced after initialization.\n  readonly roomMediaObjects: RoomMediaObjectsState | null;\n  readonly selectedMediaSurfaceId: string;\n  participantId: string;\n  mediaSurfaceViews: Pick<ReadonlySet<string>, "has">;\n}\n`;
const movedBodies = bodies.map(s => s.replace(/\broomMediaObjects\b/g, 'context.roomMediaObjects').replace(/\bselectedMediaSurfaceId\b/g, 'context.selectedMediaSurfaceId')).join('\n\n');
const moduleSource = moduleImports + interfaceText + `\nexport function createMediaObjectQueries(context: MediaObjectQueriesContext) {\n  const { participantId, mediaSurfaceViews } = context;\n\n` + movedBodies.split('\n').map(l => l ? '  ' + l : l).join('\n') + `\n\n  return {\n${publicNames.map(n => `    ${n}`).join(',\n')}\n  };\n}\n`;
const wiring = `const {\n${publicNames.map(n => `  ${n}`).join(',\n')}\n} = createMediaObjectQueries({\n  get roomMediaObjects() { return roomMediaObjects; },\n  get selectedMediaSurfaceId() { return selectedMediaSurfaceId; },\n  participantId,\n  mediaSurfaceViews\n});\n`;
const edits = functions.map(n => ({ start: n.getStart(ast), end: n.end + 2, text: '' }));
for (const e of edits) if (source.slice(e.end - 2, e.end) !== '\n\n') throw new Error('Unexpected function separator');
const oldImport = selectorImport.getText(ast);
const newImport = `import {\n  physicalRemoteBrowserObjectForMediaTrack,\n  physicalScreenShareObjectForMediaTrack\n} from "./media/media-object-state.js";`;
edits.push({ start: selectorImport.getStart(ast), end: selectorImport.end, text: newImport });
const lastImport = ast.statements.filter(ts.isImportDeclaration).at(-1);
const newImportLine = '\nimport { createMediaObjectQueries } from "./media/media-object-queries.js";';
edits.push({ start: lastImport.end, end: lastImport.end, text: newImportLine });
const anchor = 'let selectedMediaSurfaceId = DEBUG_SURFACE_ID;\n';
if (source.split(anchor).length !== 2) throw new Error('Unexpected wiring anchor');
const position = source.indexOf(anchor) + anchor.length;
edits.push({ start: position, end: position, text: wiring });
let candidate = source;
for (const e of edits.sort((a,b) => b.start - a.start)) candidate = candidate.slice(0,e.start) + e.text + candidate.slice(e.end);
fs.writeFileSync(file, candidate);
fs.writeFileSync(path.join(root, 'apps/runtime-web/src/media/media-object-queries.ts'), moduleSource);
const metadata = { names, publicNames, bodies, oldImport, newImport, newImportLine, anchor, wiring, originalLineCount: source.trimEnd().split('\n').length, candidateLineCount: candidate.trimEnd().split('\n').length, moduleLineCount: moduleSource.trimEnd().split('\n').length };
fs.writeFileSync(path.join(process.env.EVIDENCE ?? path.dirname(file), 'extraction.json'), JSON.stringify(metadata,null,2));
console.log(JSON.stringify({ functions: names.length, publicFunctions: publicNames.length, mainBefore: metadata.originalLineCount, mainAfter: metadata.candidateLineCount, module: metadata.moduleLineCount }));
