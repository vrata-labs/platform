import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
const root = path.resolve(process.argv[2] ?? '.');
const require = createRequire(path.join(root, 'package.json'));
const ts = require('typescript');
const evidence = path.resolve(process.env.EVIDENCE ?? '/tmp/media-object-queries-evidence');
const metadata = JSON.parse(fs.readFileSync(path.join(evidence, 'extraction.json'), 'utf8'));
const source = fs.readFileSync(path.join(evidence, 'main-baseline.ts'), 'utf8');
const candidate = fs.readFileSync(path.join(root, 'apps/runtime-web/src/main.ts'), 'utf8');
const moduleSource = fs.readFileSync(path.join(root, 'apps/runtime-web/src/media/media-object-queries.ts'), 'utf8');
const parse = (s) => ts.createSourceFile('file.ts', s, ts.ScriptTarget.Latest, true);
const originalAst = parse(source), candidateAst = parse(candidate), moduleAst = parse(moduleSource);
const functions = (ast) => ast.statements.filter(n => ts.isFunctionDeclaration(n) && metadata.names.includes(n.name?.text));
const originalFunctions = functions(originalAst);
assert.equal(originalFunctions.length, 29);
assert.equal(functions(candidateAst).length, 0);
const factory = moduleAst.statements.find(n => ts.isFunctionDeclaration(n) && n.name?.text === 'createMediaObjectQueries');
assert.ok(factory);
assert.equal(factory.body.statements.length, 31);
const extracted = factory.body.statements.filter(ts.isFunctionDeclaration);
const printer = ts.createPrinter({ removeComments: true });
const print = n => printer.printNode(ts.EmitHint.Unspecified, n, n.getSourceFile());
for (const n of originalFunctions) {
  const moved = extracted.find(f => f.name?.text === n.name.text);
  assert.ok(moved, n.name.text);
  const restored = parse(moved.getText(moduleAst).replace(/\bcontext\.(roomMediaObjects|selectedMediaSurfaceId)\b/g, '$1'));
  assert.equal(print(restored.statements[0]), print(n), `Source function mismatch: ${n.name.text}`);
}
assert.equal(factory.body.statements[0].getText(moduleAst), 'const { participantId, mediaSurfaceViews } = context;');
const returned = factory.body.statements.at(-1);
assert.ok(ts.isReturnStatement(returned));
assert.deepEqual(returned.expression.properties.map(n => n.name.text), metadata.publicNames);
const importNode = originalAst.statements.find(n => ts.isImportDeclaration(n) && n.moduleSpecifier.text === './media/media-object-state.js');
const lastImport = originalAst.statements.filter(ts.isImportDeclaration).at(-1);
const anchorPosition = source.indexOf(metadata.anchor) + metadata.anchor.length;
const edits = originalFunctions.map(n => ({ start: n.getStart(originalAst), end: n.end + 2, text: '' }));
edits.push({ start: importNode.getStart(originalAst), end: importNode.end, text: metadata.newImport });
edits.push({ start: lastImport.end, end: lastImport.end, text: metadata.newImportLine });
edits.push({ start: anchorPosition, end: anchorPosition, text: metadata.wiring });
let delta = 0;
const inverse = [];
for (const e of edits.sort((a,b) => a.start-b.start)) {
  const start = e.start + delta;
  assert.equal(candidate.slice(start, start + e.text.length), e.text);
  inverse.push({ start, end: start + e.text.length, text: source.slice(e.start,e.end) });
  delta += e.text.length - (e.end-e.start);
}
let restoredSource = candidate;
for (const e of inverse.reverse()) restoredSource = restoredSource.slice(0,e.start) + e.text + restoredSource.slice(e.end);
assert.equal(restoredSource, source, 'Exact inverse source reconstruction');
// No query identifier occurs before initialization; late snapshots stay behind getters.
const earlyUses = [];
function earlyVisit(n) {
  if (n.pos >= anchorPosition || ts.isImportDeclaration(n)) return;
  if (ts.isIdentifier(n) && metadata.names.includes(n.text)) earlyUses.push(n.text);
  ts.forEachChild(n, earlyVisit);
}
earlyVisit(originalAst);
assert.deepEqual(earlyUses, []);
const sourceReport = { functions: 29, publicFunctions: 28, exactInverse: true, bodiesEqual: true, noEarlyQueryUses: true,
  mainBefore: metadata.originalLineCount, mainAfter: metadata.candidateLineCount };
fs.writeFileSync(path.join(evidence,'source-equivalence.json'),JSON.stringify(sourceReport,null,2));
console.log(JSON.stringify(sourceReport));
if (process.argv.includes('--source-only')) process.exit(0);
const baselineDir = path.resolve(process.env.BASELINE_DIST ?? path.join(evidence,'baseline-runtime-dist'));
const candidateDir = path.resolve(process.env.CANDIDATE_DIST ?? path.join(root,'apps/runtime-web/dist'));
const baseJs = fs.readFileSync(path.join(baselineDir,'main.js'),'utf8');
const newJs = fs.readFileSync(path.join(candidateDir,'main.js'),'utf8');
const baseAst = parse(baseJs), newAst = parse(newJs);
const compiledModule = fs.readFileSync(path.join(candidateDir,'media/media-object-queries.js'),'utf8');
const compiledModuleAst = parse(compiledModule);
const compiledFactory = compiledModuleAst.statements.find(n => ts.isFunctionDeclaration(n) && n.name?.text === 'createMediaObjectQueries');
for (const n of functions(baseAst)) {
  const moved = compiledFactory.body.statements.find(f => ts.isFunctionDeclaration(f) && f.name?.text === n.name.text);
  const restored = parse(moved.getText(compiledModuleAst).replace(/\bcontext\.(roomMediaObjects|selectedMediaSurfaceId)\b/g, '$1'));
  assert.equal(print(restored.statements[0]), print(n), `Compiled function mismatch: ${n.name.text}`);
}
const findImport = ast => ast.statements.find(n => ts.isImportDeclaration(n) && n.moduleSpecifier.text === './media/media-object-state.js');
const compiledWiring = newAst.statements.find(n => ts.isVariableStatement(n) && n.declarationList.declarations.some(d => d.initializer && ts.isCallExpression(d.initializer) && d.initializer.expression.getText(newAst) === 'createMediaObjectQueries'));
const compiledNewImport = newAst.statements.find(n => ts.isImportDeclaration(n) && n.moduleSpecifier.text === './media/media-object-queries.js');
const compiledLastImport = baseAst.statements.filter(ts.isImportDeclaration).at(-1);
const compiledAnchor = baseAst.statements.find(n => ts.isVariableStatement(n) && n.declarationList.declarations.some(d => d.name.getText(baseAst) === 'selectedMediaSurfaceId'));
const compiledEdits = functions(baseAst).map(n => ({start:n.getStart(baseAst),end:n.end+1,text:''}));
compiledEdits.push({start:findImport(baseAst).getStart(baseAst),end:findImport(baseAst).end,text:findImport(newAst).getText(newAst)});
compiledEdits.push({start:compiledLastImport.end,end:compiledLastImport.end,text:'\n'+compiledNewImport.getText(newAst)});
compiledEdits.push({start:compiledAnchor.end+1,end:compiledAnchor.end+1,text:compiledWiring.getText(newAst)+'\n'});
let expectedJs = baseJs;
for(const e of compiledEdits.sort((a,b)=>b.start-a.start)) expectedJs=expectedJs.slice(0,e.start)+e.text+expectedJs.slice(e.end);
fs.writeFileSync(path.join(evidence,'expected-main.js'),expectedJs);
assert.equal(newJs,expectedJs,'Exact compiled-main reconstruction');
function allJs(dir,prefix='') {
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => {
    if(e.name==='assets')return [];
    const rel=path.join(prefix,e.name), full=path.join(dir,e.name);
    return e.isDirectory()?allJs(full,rel):(e.name.endsWith('.js')?[rel]:[]);
  });
}
const oldFiles = allJs(baselineDir);
for (const rel of oldFiles.filter(f=>f!=='main.js')) assert.deepEqual(fs.readFileSync(path.join(candidateDir,rel)),fs.readFileSync(path.join(baselineDir,rel)),`Unchanged emitted module: ${rel}`);
assert.deepEqual(fs.readFileSync(path.join(candidateDir,'main.d.ts')),fs.readFileSync(path.join(baselineDir,'main.d.ts')));
const report={ functions:29, exactCompiledMainReconstruction:true, oldModules:oldFiles.length, byteIdentical:oldFiles.length-1, mainDeclarationIdentical:true };
fs.writeFileSync(path.join(evidence,'compiled-equivalence.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
// Execute the same tests against original compiler output, not candidate-derived implementations.
const imports=importNode.importClause.namedBindings.elements.filter(e=>!e.name.text.startsWith('physical'));
const bindingPairs=imports.map(e=>`${e.name.text}: selectors.${e.propertyName?.text??e.name.text}`);
const originalCompiledFunctions = functions(baseAst).map(n=>n.getText(baseAst)).join('\n\n');
const originalBody = `with (context) {\n${originalCompiledFunctions}\nreturn {${metadata.publicNames.join(',')}};\n}`;
const baselineModule = `import * as shared from '@vrata/shared-types';\nimport * as selectors from './media-object-state.js';\nconst bindings = {...shared,${bindingPairs.join(',')}};\nexport function createMediaObjectQueries(context) {\n  return Function(...Object.keys(bindings), 'context', ${JSON.stringify(originalBody)})(...Object.values(bindings), context);\n}\n`;
const modulePath=path.join(candidateDir,'media/media-object-queries.js');
try {
  fs.writeFileSync(modulePath,baselineModule);
  const result=spawnSync(process.execPath,['--test',path.join(candidateDir,'media/media-object-queries.test.js')],{cwd:root,encoding:'utf8'});
  fs.writeFileSync(path.join(evidence,'baseline-characterization.log'),result.stdout+result.stderr);
  assert.equal(result.status,0,result.stdout+result.stderr);
  console.log('Original compiled baseline: all characterization tests passed');
} finally { fs.writeFileSync(modulePath,compiledModule); }
