import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const root = path.resolve(process.argv[2] || '.');
const require = createRequire(path.join(root, 'package.json'));
const ts = require('typescript');
const mainPath = path.join(root, 'apps/runtime-web/src/main.ts');
const source = fs.readFileSync(mainPath, 'utf8');
const file = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
const keys = [
  'sendPrivilegedSurfaceCreate','createSurfaceTestCard','createExtensionTestCard',
  'createMissingCapabilityExtensionObject','createDisabledExtensionObject',
  'createScreenShareObject','createWhiteboardObject','createMarkdownBoardObject',
  'createStickyNote','updateStickyNote','moveStickyNote','deleteStickyNote',
  'createRemoteBrowserObject','takeRemoteBrowserControl','releaseRemoteBrowserControl',
  'createUnknownSurfaceObject','stopActiveSurfaceObject','sendStaleSurfaceTestCardPatch',
  'sendStaleScreenSharePatch','sendStaleWhiteboardPatch','sendStaleMarkdownBoardPatch',
  'sendDuplicateMarkdownBoardPatch','sendDuplicateWhiteboardPatch',
  'clearWhiteboardObject','setDebugSurfaceMediaAudioEnabled'
];
const assignment = file.statements.find(s => ts.isExpressionStatement(s)
  && ts.isBinaryExpression(s.expression) && s.expression.left.getText(file).endsWith('.__VRATA_TEST__'));
if (!assignment) throw new Error('test_api_assignment_not_found');
const binary = assignment.expression;
const typeLiteral = binary.left.expression.expression.type.types[1];
const apiType = typeLiteral.members[0].type;
const methods = keys.map(key => {
  const prop = binary.right.properties.find(p => p.name?.getText(file) === key);
  const member = apiType.members.find(p => p.name?.getText(file) === key);
  if (!prop || !member) throw new Error(`test_api_method_missing:${key}`);
  return {key, prop, member};
});
const staticNames = [
  'participantId','mediaSurfaceCommands','activeMediaObjectForSurface',
  'activeScreenShareObjectForSurface','findActiveScreenShareObject',
  'activeWhiteboardObjectForSurface','getWhiteboardRuntime',
  'activeMarkdownBoardObjectForSurface','findActiveMarkdownBoardObject',
  'getMarkdownBoardRuntime','latestStickyNoteId',
  'activeRemoteBrowserObjectForSurface','findActiveRemoteBrowserObject','getRemoteBrowserRuntime'
];
const header = `import {
  DISABLED_EXTENSION_CARD_TYPE,
  EXTENSION_TEST_CARD_TYPE,
  MARKDOWN_BOARD_OBJECT_TYPE,
  MISSING_CAPABILITY_EXTENSION_CARD_TYPE,
  REMOTE_BROWSER_OBJECT_TYPE,
  SCREEN_SHARE_OBJECT_TYPE,
  SURFACE_TEST_CARD_TYPE,
  WHITEBOARD_OBJECT_TYPE,
  hasRoomPermission,
  type MarkdownBoardState,
  type MediaObjectInstance,
  type RemoteBrowserObjectState,
  type RoomPermission,
  type ScreenShareObjectState,
  type WhiteboardState
} from "@vrata/shared-types";

import type { MarkdownBoardObjectRuntime } from "../media/markdown-board-object.js";
import type { MediaSurfaceCommandClient } from "../media/media-surface-commands.js";
import type { RemoteBrowserObjectRuntime } from "../media/remote-browser-object.js";
import type { WhiteboardObjectRuntime } from "../media/whiteboard-object.js";

export interface MediaObjectTestControlsContext {
  participantId: string;
  debugSurfaceId: string;
  // Supply getters for mutable runtime state; never capture a selection or permissions snapshot.
  readonly selectedMediaSurfaceId: string;
  readonly permissions: readonly RoomPermission[];
  mediaSurfaceCommands: Pick<MediaSurfaceCommandClient, "createCommandId" | "sendCreateObject" | "sendStopObject" | "sendPatchObjectState" | "sendMediaAudio">;
  activeMediaObjectForSurface: (surfaceId: string) => MediaObjectInstance | null;
  activeScreenShareObjectForSurface: (surfaceId: string) => MediaObjectInstance<ScreenShareObjectState> | null;
  findActiveScreenShareObject: () => MediaObjectInstance<ScreenShareObjectState> | null;
  activeWhiteboardObjectForSurface: (surfaceId: string) => MediaObjectInstance<WhiteboardState> | null;
  getWhiteboardRuntime: (surfaceId: string) => Pick<WhiteboardObjectRuntime, "createClearPatch">;
  activeMarkdownBoardObjectForSurface: (surfaceId: string) => MediaObjectInstance<MarkdownBoardState> | null;
  findActiveMarkdownBoardObject: () => MediaObjectInstance<MarkdownBoardState> | null;
  getMarkdownBoardRuntime: (surfaceId: string) => Pick<MarkdownBoardObjectRuntime, "createNotePatch" | "createUpdateNotePatch" | "createMoveNotePatch" | "createDeleteNotePatch">;
  latestStickyNoteId: (object: MediaObjectInstance<MarkdownBoardState> | null) => string | null;
  activeRemoteBrowserObjectForSurface: (surfaceId: string) => MediaObjectInstance<RemoteBrowserObjectState> | null;
  findActiveRemoteBrowserObject: () => MediaObjectInstance<RemoteBrowserObjectState> | null;
  getRemoteBrowserRuntime: (surfaceId: string) => Pick<RemoteBrowserObjectRuntime, "createTakeControlPatch" | "createReleaseControlPatch">;
}

export interface MediaObjectTestControls {
${methods.map(({member})=>'  '+member.getText(file)).join('\n')}
}

export function createMediaObjectTestControls(context: MediaObjectTestControlsContext): MediaObjectTestControls {
  const {
    debugSurfaceId: DEBUG_SURFACE_ID,
${staticNames.map(n=>'    '+n).join(',\n')}
  } = context;

  return {
`;
const transformed = methods.map(({prop}) => prop.getText(file)
  .replaceAll('selectedMediaSurfaceId', 'context.selectedMediaSurfaceId')
  .replaceAll('debugState.access.permissions', 'context.permissions'));
const moduleText = header + transformed.map(p => p.split('\n').map((l,i)=>(i===0?'    ':'  ')+l).join('\n')).join(',\n') + '\n  };\n}\n';
const edits = methods.map(({prop,key}) => ({start:prop.getStart(file),end:prop.end,text:`${key}: mediaObjectTestControls.${key}`}));
const initialization = `const mediaObjectTestControls = createMediaObjectTestControls({
  debugSurfaceId: DEBUG_SURFACE_ID,
  get selectedMediaSurfaceId() { return selectedMediaSurfaceId; },
  get permissions() { return debugState.access.permissions; },
${staticNames.map(n=>'  '+n).join(',\n')}
});
`;
edits.push({start:assignment.getStart(file),end:assignment.getStart(file),text:initialization});
const importLine = 'import { createMediaObjectTestControls } from "./testing/media-object-test-controls.js";\n';
edits.push({start:0,end:0,text:importLine});
let candidate=source;
for (const e of edits.sort((a,b)=>b.start-a.start)) candidate=candidate.slice(0,e.start)+e.text+candidate.slice(e.end);
const unusedImports = ['DISABLED_EXTENSION_CARD_TYPE', 'EXTENSION_TEST_CARD_TYPE', 'MISSING_CAPABILITY_EXTENSION_CARD_TYPE'];
for (const name of unusedImports) candidate = candidate.replace(`  ${name},\n`, '');
// Prove the original file can be reconstructed before writing anything.
let inverse=candidate;
for(const {key,prop} of methods) inverse=inverse.replace(`${key}: mediaObjectTestControls.${key}`,prop.getText(file));
inverse=inverse.replace(importLine,'').replace(initialization,'');
const originalImport = source.slice(file.statements[2].getStart(file), file.statements[2].end);
const currentFile = ts.createSourceFile('main.ts', inverse, ts.ScriptTarget.Latest, true);
const currentImport = currentFile.statements[2];
inverse = inverse.slice(0,currentImport.getStart(currentFile)) + originalImport + inverse.slice(currentImport.end);
if(inverse!==source) throw new Error('inverse_reconstruction_failed');
const out=path.join(root,'apps/runtime-web/src/testing');fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(path.join(out,'media-object-test-controls.ts'),moduleText);
fs.writeFileSync(mainPath,candidate);
console.log(JSON.stringify({methods:keys.length,originalLines:source.split('\n').length-1,candidateLines:candidate.split('\n').length-1,moduleLines:moduleText.split('\n').length-1,keys},null,2));
