import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
const root=process.cwd();
const require=createRequire(path.join(root,'package.json'));
const ts=require('typescript');
const evidence=process.env.EVIDENCE || path.resolve(root,'../checks');
fs.mkdirSync(evidence,{recursive:true});
const parse=(name,text)=>ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true);
const printer=ts.createPrinter({removeComments:true});
const print=(node,file)=>printer.printNode(ts.EmitHint.Unspecified,node,file);
const assignment=file=>file.statements.find(s=>ts.isExpressionStatement(s)&&ts.isBinaryExpression(s.expression)&&s.expression.left.getText(file).endsWith('.__VRATA_TEST__'));
const sourcePath='apps/runtime-web/src/main.ts';
const modulePath='apps/runtime-web/src/testing/media-object-test-controls.ts';
const baseline=fs.readFileSync(process.env.BASELINE_MAIN || path.join(evidence,'main-baseline.ts'),'utf8');
const current=fs.readFileSync(sourcePath,'utf8');
const moduleText=fs.readFileSync(modulePath,'utf8');
const before=parse('main.ts',baseline), after=parse('main.ts',current), moduleFile=parse('module.ts',moduleText);
const factory=moduleFile.statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text==='createMediaObjectTestControls');
const ret=factory.body.statements.find(ts.isReturnStatement).expression;
const keys=ret.properties.map(p=>p.name.getText(moduleFile));
assert.equal(keys.length,25);
const beforeAssignment=assignment(before), afterAssignment=assignment(after);
const beforeProps=beforeAssignment.expression.right.properties, afterProps=afterAssignment.expression.right.properties;
assert.deepEqual(beforeProps.map(p=>p.name.getText(before)),afterProps.map(p=>p.name.getText(after)));
let inverse=current;
for(const key of keys){
 const old=beforeProps.find(p=>p.name.getText(before)===key);
 const moved=ret.properties.find(p=>p.name.getText(moduleFile)===key);
 const restored=moved.getText(moduleFile).replaceAll('context.selectedMediaSurfaceId','selectedMediaSurfaceId').replaceAll('context.permissions','debugState.access.permissions');
 const temp=parse('property.ts',`const value = {${restored}};`);
 assert.equal(print(temp.statements[0].declarationList.declarations[0].initializer.properties[0],temp),print(old,before),key);
 assert.equal(afterProps.find(p=>p.name.getText(after)===key).initializer.getText(after),`mediaObjectTestControls.${key}`);
 inverse=inverse.replace(`${key}: mediaObjectTestControls.${key}`,old.getText(before));
}
const wiring=after.statements.find(s=>ts.isVariableStatement(s)&&s.declarationList.declarations[0].name.getText(after)==='mediaObjectTestControls');
const expectedWiring=`const mediaObjectTestControls = createMediaObjectTestControls({
  debugSurfaceId: DEBUG_SURFACE_ID,
  get selectedMediaSurfaceId() { return selectedMediaSurfaceId; },
  get permissions() { return debugState.access.permissions; },
  participantId,
  mediaSurfaceCommands,
  activeMediaObjectForSurface,
  activeScreenShareObjectForSurface,
  findActiveScreenShareObject,
  activeWhiteboardObjectForSurface,
  getWhiteboardRuntime,
  activeMarkdownBoardObjectForSurface,
  findActiveMarkdownBoardObject,
  getMarkdownBoardRuntime,
  latestStickyNoteId,
  activeRemoteBrowserObjectForSurface,
  findActiveRemoteBrowserObject,
  getRemoteBrowserRuntime
});`;
assert.equal(wiring.getText(after),expectedWiring);
assert.equal(after.statements.indexOf(wiring)+1,after.statements.indexOf(afterAssignment));
inverse=inverse.replace(wiring.getText(after)+'\n','');
inverse=inverse.replace('import { createMediaObjectTestControls } from "./testing/media-object-test-controls.js";\n','');
const parsedInverse=parse('main.ts',inverse);
const sharedImport=parsedInverse.statements.find(s=>ts.isImportDeclaration(s)&&s.moduleSpecifier.text==='@vrata/shared-types');
const oldSharedImport=before.statements.find(s=>ts.isImportDeclaration(s)&&s.moduleSpecifier.text==='@vrata/shared-types');
inverse=inverse.replace(sharedImport.getText(parsedInverse),oldSharedImport.getText(before));
assert.equal(inverse,baseline,'exact inverse reconstruction');
const summary={methods:keys.length,apiKeys:beforeProps.length,baselineLines:baseline.split('\n').length-1,currentLines:current.split('\n').length-1,inverseReconstruction:true,apiPropertyOrderPreserved:true,liveStateWiringVerified:true};
fs.writeFileSync(path.join(evidence,'source-equivalence.json'),JSON.stringify(summary,null,2));
console.log(summary);
if(process.argv.includes('--source-only'))process.exit(0);
const baselineDist=process.env.BASELINE_DIST || path.join(evidence,'baseline-runtime-dist');
const candidateDist=process.env.CANDIDATE_DIST || path.join(root,'apps/runtime-web/dist');
const originalJs=fs.readFileSync(path.join(baselineDist,'main.js'),'utf8');
const originalFile=parse('main.js',originalJs);
const originalProps=assignment(originalFile).expression.right.properties;
const movedProps=keys.map(key=>originalProps.find(p=>p.name.getText(originalFile)===key).getText(originalFile));
const emittedPath=path.join(candidateDist,'testing/media-object-test-controls.js');
const emittedText=fs.readFileSync(emittedPath,'utf8');
const emittedFile=parse('module.js',emittedText);
const emittedFactory=emittedFile.statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text==='createMediaObjectTestControls');
const emittedProps=emittedFactory.body.statements.find(ts.isReturnStatement).expression.properties;
for(let i=0;i<keys.length;i++){
 const normalized=emittedProps[i].getText(emittedFile).replaceAll('context.selectedMediaSurfaceId','selectedMediaSurfaceId').replaceAll('context.permissions','debugState.access.permissions');
 const ref=parse('property.js',`const value={${normalized}};`);
 assert.equal(print(ref.statements[0].declarationList.declarations[0].initializer.properties[0],ref),print(originalProps.find(p=>p.name.getText(originalFile)===keys[i]),originalFile),keys[i]);
}
// This temporary reference executes the ORIGINAL emitted property initializers, not reconstructed candidate functions.
// The non-strict Function scope supplies mutable original globals without rewriting their function bodies.
const reference=`import * as constants from "@vrata/shared-types";\nconst instantiate = new Function("constants", "scope", ${JSON.stringify('with (constants) { with (scope) { return ({'+movedProps.join(',\n')+'}); } }')});\nexport function createMediaObjectTestControls(context) {\n  const scope = Object.create(context, {\n    DEBUG_SURFACE_ID: { value: context.debugSurfaceId },\n    debugState: { value: { access: { get permissions() { return context.permissions; } } } }\n  });\n  return instantiate(constants, scope);\n}\n`;
const testPath=path.join(candidateDist,'testing/media-object-test-controls.test.js');
const refPath=path.join(candidateDist,'testing/media-object-test-controls.baseline.js');
const refTest=path.join(candidateDist,'testing/media-object-test-controls.baseline.test.js');
fs.writeFileSync(refPath,reference);
fs.writeFileSync(refTest,fs.readFileSync(testPath,'utf8').replace('"./media-object-test-controls.js"','"./media-object-test-controls.baseline.js"'));
try{
 const output=execFileSync(process.execPath,['--test',refTest],{encoding:'utf8',maxBuffer:10*1024*1024});
 fs.writeFileSync(path.join(evidence,'baseline-characterization.log'),output);console.log(output.slice(-250));
}finally{fs.unlinkSync(refTest);fs.unlinkSync(refPath);}
if(!process.argv.includes('--local-subset')){
 const oldJs=fs.readdirSync(baselineDist,{recursive:true}).filter(p=>p.endsWith('.js')&&!p.startsWith('assets/'));
 const changed=oldJs.filter(p=>!fs.readFileSync(path.join(baselineDist,p)).equals(fs.readFileSync(path.join(candidateDist,p))));
 assert.deepEqual(changed,['main.js']);
 assert.ok(fs.readFileSync(path.join(baselineDist,'main.d.ts')).equals(fs.readFileSync(path.join(candidateDist,'main.d.ts'))));
 const equivalence={existingModules:oldJs.length,unchangedModules:oldJs.length-1,changed,mainDeclarationsIdentical:true,methods:keys.length};
 fs.writeFileSync(path.join(evidence,'compiled-equivalence.json'),JSON.stringify(equivalence,null,2));console.log(equivalence);
}
